
/*
The class CMyUserData1 is a simple example of runtime
user data.  Study this example first.  This user data
is not saved in .3dm files.  The next example,
CMyUserData2 demonstrates what needs to be done
to create user data that can be saved in files.
*/
class CMyUserData1 : public ON_UserData
{
public:

  /*
  Returns:
    Uuid used to identify this type of user data.
    This is the value saved in m_userdata_uuid and
    passed to ON_Object::GetUserData().
  */
  static ON_UUID Id(); 

  CMyUserData1();
  ~CMyUserData1();

  BOOL GetDescription( ON_wString& description );

  ON_wString m_my_string;
};

ON_UUID CMyUserData1::Id()
{
  // Use Microsoft's guidgen to get a unique id.

  // {1129B130-B840-...}
  static const ON_UUID id = 
  { 0x1129b130, 0xb840, ... };
  return id;
}

BOOL CMyUserData1::GetDescription( ON_wString& description )
{
  description = L"My first user data";
  return true;
}

CMyUserData1::CMyUserData1()
{
  m_userdata_uuid = CMyUserData1::Id();
  m_application_uuid = MyPlugIn().PlugInID();
  m_userdata_copycount = 1; // enable copying
}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

/*
The class CMyUserData2 is an example of runtime
user data that is saved in .3dm files.
*/
class CMyUserData2 : public ON_UserData
{
  // Opennurbs classes that are saved in .3dm files require
  // an ON_OBJECT_DECLARE call in their declaration.
  ON_OBJECT_DECLARE(CMyUserData2);
public:

  /*
  Returns:
    Uuid used to identify this type of user data.
    This is the value saved in m_userdata_uuid and
    passed to ON_Object::GetUserData().
  */
  static ON_UUID Id();

  CMyUserData2();
  ~CMyUserData2();

  // NOTE WELL:
  //   Because the members of this class are class are types 
  //   that have fully functional copy constructors and 
  //   operator=s, it is NOT necessary to provide an explicit
  //   a copy constructor and operator=.  In fact, it would 
  //   be best to use the ones C++ generates. 
  //   They are included in this example to demonstrate the
  //   correct way to implement a copy constructor and
  //   operator= because this is a task that trips up
  //   many people that attempt to implement them.
  CMyUserData2(const CMyUserData2& src);
  CMyUserData2& operator=(const CMyUserData2& src);

  // override virtual ON_UserData::GetDescription()
  BOOL GetDescription( ON_wString& description );

  // override virtual ON_UserData::Archive()
  BOOL Archive() const; 

  // override virtual ON_UserData::Write()
  BOOL Write(
         ON_BinaryArchive& binary_archive
       ) const;

  // override virtual ON_UserData::Read()
  BOOL Read(
         ON_BinaryArchive& binary_archive
       );

  // override virtual ON_UserData::Transform()
  BOOL Transform( const ON_Xform& ); 


  ON_wString m_my_string;
  ON_3dPoint m_my_point;
};

// Opennurbs classes that are saved in .3dm files require
// an ON_OBJECT_IMPLEMENT() call in their implmentation.
// Use Microsoft's guidgen to create the id.
ON_OBJECT_IMPLEMENT(CMyUserData2,ON_UserData,"0D8FA7AB-F8A4-...");

ON_UUID CMyUserData2::Id()
{
  return CMyUserData2::m_CMyUserData2_class_id.Uuid();
}

CMyUserData2::CMyUserData2()
{
  m_userdata_uuid = CMyUserData2::Id();
  m_application_uuid = MyPlugIn().PlugInID();
  m_userdata_copycount = 1; // enable copying

  // initialize your data members here
  m_my_point.Set(0.0,0.0,0.0);
}

CMyUserData2::~CMyUserData2()
{
}

CMyUserData2::CMyUserData2(const CMyUserData2& src) : ON_UserData(src)
{
  m_userdata_uuid = CMyUserData2::Id();
  m_application_uuid = MyPlugIn().PlugInID();
  // All other ON_UserData fields are correctly initialized by 
  // the ON_UserData(src) call. In fact, if src is 
  // a CMyUserData2 class, then ALL ON_UserData fields are 
  // correctly initialized by ON_UserData(src).  
  // The next 4 lines are here to handle the rare case 
  // when a class derived from CMyUserData2 is passed as src.

  // copy your data members here.
  m_my_string = src.m_my_string;
  m_my_point  = src.m_my_point;
}

CMyUserData2& CMyUserData2::operator=(const CMyUserData2& src)
{
  // NEVER set m_userdata_uuid or m_application_uuid
  // in an operator=.  These values are set when the
  // class is constructed and should not be changed.
  if ( this != &src )
  {
    // Use the base class to copy all appropriate 
    // ON_UserData fields.
    ON_UserData::operator=(src);

    // Explictly copy ONLY members you added to
    // the CMyUserData2 class.
    m_my_string = src.m_my_string;
    m_my_point  = src.m_my_point;
  }
  return *this;
}

BOOL CMyUserData2::GetDescription( ON_wString& description )
{
  description = L"My second type of user data";
  return true;
}

BOOL CMyUserData2::Archive() const 
{
  // If false is returned, nothing will be saved in
  // 3dm archives.
  return true;
}

BOOL CMyUserData2::Write(
       ON_BinaryArchive& binary_archive
     ) const
{
  int minor_version = 0;
  bool rc = binary_archive.BeginWrite3dmChunk(
                TCODE_ANONYMOUS_CHUNK,
                1,
                minor_version
                );
  if (!rc)
    return false;

  // Write class members like this
  for (;;)
  {
    // version 1.0 fields
    rc = binary_archive.WriteString(m_my_string);
    if (!rc) break;

    rc = binary_archive.WritePoint(m_my_point);
    if (!rc) break;

    // If you add data members to CMyUserData2 after you 
    // have released a product, simply increment minor_version
    // by one, and write the new information.  This way you
    // can enhance your user data over several versions of
    // your product without breaking file IO.  It is CRITICAL
    // that once you write something to a customer's .3dm
    // file, you continue to write it the same way for all
    // future versions.
    
    // version 1.1 fields added DD MMM YYYY
    // rc = binary_archive.WriteSomethingNew( ... );
    // if (!rc) break;
    // rc = binary_archive.WriteSomethingElseNew( ... );
    // if (!rc) break;
    
    // version 1.2 fields added DD MMM YYYY
    // rc = binary_archive.WriteAnotherSomethingNew( ... );
    // if (!rc) break;
    // rc = binary_archive.WriteAnotherSomethingElseNew( ... );
    // if (!rc) break;

    break;
  }

  // If BeginWrite3dmChunk() returns true,
  // then EndWrite3dmChunk() must be called, 
  // even if a write operation failed.
  if ( !binary_archive.EndWrite3dmChunk() )
    rc = false;

  return rc;
}

BOOL CMyUserData2::Read(
       ON_BinaryArchive& binary_archive
     )
{
  int major_version = 0;
  int minor_version = 0;
  bool rc = binary_archive.BeginRead3dmChunk(
                TCODE_ANONYMOUS_CHUNK,
                &major_version,
                &minor_version
                );
  if (!rc)
    return false;

  // Read class members like this
  for (;;)
  {
    rc == ( 1 == major_version );
    if (!rc) break;

    // version 1.0 fields
    rc = binary_archive.ReadString(m_my_string);
    if (!rc) break;

    rc = binary_archive.ReadPoint(m_my_point);
    if (!rc) break;

    // The code in the comment below demonstrates how to
    // correctly read information added in later releases
    // of your product.
    //if ( minor_version >= 1 )
    //{
    //  // version 1.1 fields added DD MMM YYYY
    //  rc = binary_archive.ReadSomethingNew( ... );
    //  if (!rc) break;
    //  rc = binary_archive.ReadSomethingElseNew( ... );
    //  if (!rc) break;
    //  
    //  if ( minor_version >= 2 )
    //  {
    //    // version 1.2 fields added DD MMM YYYY
    //    rc = binary_archive.ReadAnotherSomethingNew( ... );
    //    if (!rc) break;
    //    rc = binary_archive.ReadAnotherSomethingElseNew( ... );
    //    if (!rc) break;
    //  }
    //}

    break;
  }

  // If BeginRead3dmChunk() returns true,
  // then EndRead3dmChunk() must be called, 
  // even if a read operation failed.
  if ( !binary_archive.EndRead3dmChunk() )
    rc = false;

  return rc;
}

BOOL CMyUserData2::Transform( const ON_Xform& xform )
{
  m_my_point = xform*m_my_point;
}

