/////////////////////////////////////////////////////////////////////////////
// TestSdkCrashPlugIn.cpp : defines the initialization routines for the plug-in.
//

#include "StdAfx.h"
#include "TestSdkCrashPlugIn.h"

#pragma warning( push )
#pragma warning( disable : 4073 )
#pragma init_seg( lib )
#pragma warning( pop )

// Rhino plug-in declaration
RHINO_PLUG_IN_DECLARE

// Rhino plug-in developer declarations
RHINO_PLUG_IN_DEVELOPER_ORGANIZATION( L"My Company Name" );
RHINO_PLUG_IN_DEVELOPER_ADDRESS( L"123 Developer Street\r\nCity State 12345-6789" );
RHINO_PLUG_IN_DEVELOPER_COUNTRY( L"My Country" );
RHINO_PLUG_IN_DEVELOPER_PHONE( L"123.456.7890" );
RHINO_PLUG_IN_DEVELOPER_FAX( L"123.456.7891" );
RHINO_PLUG_IN_DEVELOPER_EMAIL( L"support@mycompany.com" );
RHINO_PLUG_IN_DEVELOPER_WEBSITE( L"http://www.mycompany.com" );
RHINO_PLUG_IN_UPDATE_URL( L"http://www.mycompany.com/support" );

// The one and only CTestSdkCrashPlugIn object
static CTestSdkCrashPlugIn thePlugIn;

/////////////////////////////////////////////////////////////////////////////
// CTestSdkCrashPlugIn definition

CTestSdkCrashPlugIn& TestSdkCrashPlugIn()
{ 
  // Return a reference to the one and only CTestSdkCrashPlugIn object
  return thePlugIn; 
}

CTestSdkCrashPlugIn::CTestSdkCrashPlugIn()
{
  // TODO: Add construction code here
  m_plugin_version = __DATE__"  "__TIME__;
}

CTestSdkCrashPlugIn::~CTestSdkCrashPlugIn()
{
  // TODO: Add destruction code here
}

/////////////////////////////////////////////////////////////////////////////
// Required overrides

const wchar_t* CTestSdkCrashPlugIn::PlugInName() const
{
  // TODO: Return a short, friendly name for the plug-in.
  return L"TestSdkCrash";
}

const wchar_t* CTestSdkCrashPlugIn::PlugInVersion() const
{
  // TODO: Return the version number of the plug-in.
  return m_plugin_version;
}

GUID CTestSdkCrashPlugIn::PlugInID() const
{
  // TODO: Return a unique identifier for the plug-in.
  // {2CD87371-CD35-45CD-8F4C-46BED1923791}
  static const GUID TestSdkCrashPlugIn_UUID =
  { 0x2CD87371, 0xCD35, 0x45CD, { 0x8F, 0x4C, 0x46, 0xBE, 0xD1, 0x92, 0x37, 0x91 } };
  return TestSdkCrashPlugIn_UUID;
}

BOOL CTestSdkCrashPlugIn::OnLoadPlugIn()
{
  // TODO: Add plug-in initialization code here.
  return CRhinoUtilityPlugIn::OnLoadPlugIn();
}

void CTestSdkCrashPlugIn::OnUnloadPlugIn()
{
  // TODO: Add plug-in cleanup code here.
  CRhinoUtilityPlugIn::OnUnloadPlugIn();
}

