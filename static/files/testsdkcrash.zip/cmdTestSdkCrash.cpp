/////////////////////////////////////////////////////////////////////////////
// cmdTestSdkCrash.cpp : command file
//

#include "StdAfx.h"
#include "TestSdkCrashPlugIn.h"

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
//
// BEGIN TestSdkCrash command
//
class CCommandTestSdkCrash : public CRhinoCommand
{
public:
	CCommandTestSdkCrash() {}
  ~CCommandTestSdkCrash() {}
	UUID CommandUUID()
	{
		// {2B52637C-20CD-48C0-9E6A-182400E2A33B}
    static const GUID TestSdkCrashCommand_UUID =
    { 0x2B52637C, 0x20CD, 0x48C0, { 0x9E, 0x6A, 0x18, 0x24, 0x0, 0xE2, 0xA3, 0x3B } };
    return TestSdkCrashCommand_UUID;
	}
	const wchar_t* EnglishCommandName() { return L"TestSdkCrash"; }
	const wchar_t* LocalCommandName() { return L"TestSdkCrash"; }
	CRhinoCommand::result RunCommand( const CRhinoCommandContext& );
};
static class CCommandTestSdkCrash theTestSdkCrashCommand;

CRhinoCommand::result CCommandTestSdkCrash::RunCommand( const CRhinoCommandContext& context )
{
  // There are a lot of ways to crash Rhino.
  // here is an easy one...
  CRhinoView* view = 0; // null pointer
  CRhinoViewport& vp = view->Viewport();
  return success;
}

//
// END TestSdkCrash command
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
